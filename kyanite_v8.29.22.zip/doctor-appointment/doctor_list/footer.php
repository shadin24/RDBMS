		

	    </div>
		<!-- Bootstrap core JavaScript-->
	    <script src="../vendor/jquery/jquery.min.js"></script>
	    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	    <!-- Core plugin JavaScript-->
	    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

	    <script type="text/javascript" src="../vendor/parsley/dist/parsley.min.js"></script>

	    <script type="text/javascript" src="../vendor/datepicker/bootstrap-datepicker.js"></script>

	    <!-- Page level plugins -->
	    <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
	    <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>

	</body>
</html>